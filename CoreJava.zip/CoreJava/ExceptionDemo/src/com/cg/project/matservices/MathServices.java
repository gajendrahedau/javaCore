package com.cg.project.matservices;

public class MathServices {
	public abstract int addNumber

}
