public class FrequencyOfEachDigit {
	public static void main(String[] args) {
		int digits[]={10,10,10,10,12,12,11,45};
		int newArray[]=new int[60];
		for(int i=0;i<newArray.length;i++)
			newArray[i]=0;
		for(int i=0;i<digits.length;i++)
			newArray[digits[i]]++;
		for(int i=0;i<newArray.length;i++)
			if(newArray[i]!=0)
				System.out.println((i)+" Occurs "+newArray[i]+" times");
	}

}
