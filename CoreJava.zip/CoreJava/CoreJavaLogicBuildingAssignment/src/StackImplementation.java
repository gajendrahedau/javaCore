import java.util.Stack;
public class StackImplementation {
	public static void main(String args[]){
		Stack<Integer> stack=new Stack<Integer>();
		stack.push(90);
		stack.push(20);
		stack.push(50);
		stack.push(40);
		stack.push(50);
		System.out.println(stack);
		stack.pop();
		System.out.println(stack);
		System.out.println(stack.peek());
		stack.pop();
		System.out.println(stack.size());
	}
}
