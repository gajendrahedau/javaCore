
public class LinearArraySearch {

	public static void main(String[] args) {
		int number[]={1,2,3,4,5,6,7,8,9};
		int i=0,flag=0,search=20;
		while (i<number.length) {
			if(number[i]==search){
				flag=1;
				System.out.println("Found");
				break;
			}
			i++;
		}
		if(flag==0)
			System.out.println("Not Found");
	}
}
