public class FindOddAndEvenNumbers {
	public static void main(String[] args) {
		int x=20,y=40;
		System.out.println("Even Numbers are:\n");
	    for(int i=x;i<=y;i++){
	    	if(i%2==0){
	    		System.out.println(i+"\n");
	    	}
	    }
		System.out.println("Odd Numbers are:\n");
	    for(int i=x;i<=y;i++){
	    	if(i%2!=0){
	    		System.out.println(i+"\n");
	    	}
	    }

	}

}
