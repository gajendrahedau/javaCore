
public class ArmstrongNumber1 {
	public static void main(String[] args) {
			int no= 371,sum=0,r,p;
			p=no;
			while(no!=0){
				r=no%10;
				sum=sum+r*r*r;
				no=no/10;
			}
			if(sum==p)
			System.out.println("The given no. is an Armstrong number");
			else
			System.out.println("The given no. is not an Armstrong number");
		}
}