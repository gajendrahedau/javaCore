//[1,2,3,4,5,6,7,8,9] 
//[10,1,9,2,8,3,7,4,6,5]
class ArrayConversionFormat2{
	public static void main(String args[]){
		System.out.println("Given array format: [1,2,3,4,5,6,7,8,9]");
		int numbers[]={1,2,3,4,5,6,7,8,9,10};
		int newArray[]=new int[10];
		int j=0,i;
		for(i=numbers.length-1;i>=numbers.length/2;i--){
			newArray[j]=numbers[i];
			j=j+2;
		
		}
		j=1;
		for(i=0;i<numbers.length/2;i++){
			newArray[j]=numbers[i];
			j=j+2;
		}
		System.out.print("Array format after conversion: [");
		for(i=0;i<numbers.length;i++)
			System.out.print(newArray[i]+",");
		System.out.print("]");
	}
}