import java.util.Arrays;
public class LargestAndSmallestNumber {
	public static void main(String[] args) {
		int number = 1009278;
		System.out.print("Given number is:"+number);
		int count=0,n=number,i=0,j=0;
		while(n!=0){
			n/=10;
			count++;
		}
		int[] array= new int[count] ;
		if(count!=0){
			count=0;
			n=number;
			while(n!=0){
				array[count]=n%10;
				n/=10;	
				count++;
			}
		}	
		 Arrays.sort(array);
		 System.out.print("\nLargest number is: ");
		for(i=count;i>0;i--)
			System.out.print(array[i-1]);
		if(array[0]==0){
			while(array[j]==0)
				j++;
			array[0]=array[j];
			array[j]=0;
			 System.out.print("\nSmallest number is: ");
				for(i=0;i<count;i++)
					System.out.print(array[i]);
		}
		else{
			 System.out.print("\nSmallest number is: ");
				for(i=0;i<count;i++)
					System.out.print(array[i]);
		}
	}
}