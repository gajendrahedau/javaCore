public class OddNumberInARange {
	public static void main(String[] args) {
		int x=12,y=56;
		System.out.println("Odd Numbers are:");
		 for(int i=x;i<=y;i++){
		    	if(i%2!=0)
		    		System.out.println(i+"\n");
		    }
	}
}