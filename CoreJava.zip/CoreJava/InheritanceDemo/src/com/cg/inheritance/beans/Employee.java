package com.cg.inheritance.beans;

public abstract class Employee {
	private int employeeId;
	private String firsName,lastName;
	private int basicSalary,totalSalary;
	
	public Employee() {}

	public Employee(int employeeId, String firsName, String lastName,
			int basicSalary) {
		super();
		this.employeeId = employeeId;
		this.firsName = firsName;
		this.lastName = lastName;
		this.basicSalary = basicSalary;
	}

	public  abstract void calculateTotalSalary();
	
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirsName() {
		return firsName;
	}

	public void setFirsName(String firsName) {
		this.firsName = firsName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getTotalSalary() {
		return totalSalary;
	}

	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}

	@Override
	public String toString() {
		return "employeeId=" + employeeId + ", firsName=" + firsName
				+ ", lastName=" + lastName + ", basicSalary=" + basicSalary
				+ ", totalSalary=" + totalSalary ;
	}

	
}
