package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.HashMap;
import com.cg.payroll.beans.Associate;
public class AssociateDAOImpl implements AssociateDAO{
	private static int ASSOCIATE_COUNTER=101;
	private static HashMap<Integer, Associate> associates=new HashMap<>();
	@Override
	public Associate save(Associate associate) {
		associate.setAssociateID(ASSOCIATE_COUNTER++);
		associates.put(associate.getAssociateID(), associate);
		return associate;
	}
	@Override
	public Associate findOne(int associateId) {
		return associates.get(associateId);
	}
	@Override
	public ArrayList<Associate> findAll() {
		return new ArrayList<>(associates.values());
	}
}
