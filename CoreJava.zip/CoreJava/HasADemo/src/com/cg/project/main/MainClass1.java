package com.cg.project.main;

import com.cg.project.beans.Address;
import com.cg.project.beans.Customer;

public class MainClass1 {
	public static void main(String args[]){
		Address address=new Address("Jodhpur", "Rajasthan", "India", 344022);
		Customer customer=new Customer(101, "Gajendra", "Hedau", address);
		
		customer.setAddress(new Address("Pune", "Maharashtra", "India", 401157));
		
		System.out.println(customer.getAddress().getCity());
		
	}

}
