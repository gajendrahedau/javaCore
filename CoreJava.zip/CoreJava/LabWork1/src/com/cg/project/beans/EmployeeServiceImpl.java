package com.cg.project.beans;

import java.util.HashMap;
import java.util.Map;

public class EmployeeServiceImpl{
	private static Map<String, Employee> hashmap=new HashMap<>();
	public void getEmployeeDetails(int id,int salary,String name,String designation,String scheme) {
		Employee employee=new Employee(id, salary, name, designation,scheme);
		hashmap.put(scheme,employee);
	}
	public void display() {
		for (Employee emp:hashmap.values()) {
			System.out.println(emp);
		}
	}
}
