package com.cg.project.thread;

import java.util.Timer;
import java.util.TimerTask;

public class TimerClassExample {
	public static void main(String[] args) {
		new Timer().scheduleAtFixedRate( ,0, 1000);
	}

}
