package com.cg.project.thread;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread{
	public CopyDataThread() {}
	
	public CopyDataThread(String string) {super(string);}

	@Override
	public void run() {
		try(FileInputStream fileInputStream=new FileInputStream(new File("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\source.txt"));
				FileOutputStream fileOutputStream=new FileOutputStream(new File("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\target.txt"))){
				int i,count=0;
			while((i=fileInputStream.read())!=-1){
				fileOutputStream.write((char)i);
				count++;
				if(count%10==0){
					System.out.println("10 characters are copied.");
					Thread.sleep(5000);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
