package com.cg.project.collectiondemo;

import java.util.HashMap;

public class HashMapDemo {
	private static HashMap<String, String> hashmap=new HashMap<>();
	public static HashMap<String, String> hashmap(){
		hashmap.put("A", new String("Gajju"));
		hashmap.put("B", new String("Atul"));
		hashmap.put("A", new String("Appu"));
		hashmap.put("E", new String("Ashu"));
		hashmap.put("A", new String("Anu"));
		for(String s:hashmap.values())
		System.out.println(s);
		return hashmap;
	}
	
}
