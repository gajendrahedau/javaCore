package com.cg.banking.beans;

public class Address {
	String city ,state ,pinCode ,country; 
}
