package com.cg.project.lambdainterface;
public class ThreadWithLambdaExpression {
	public static void main(String[] args) {
		Runnable runnableResource=()->{
			for(int i=0;i<10;i++)
				System.out.println("Tick "+i);
		};
		Thread th1=new Thread(runnableResource);
		th1.start();
		
		
		
	}
}
