package com.cg.project.lambdainterface;
public class MainClass {
	public static void main(String[] args) {
		FunctionalInterface1 functionalInterface1=(fname,lname)->System.out.println("Hello"+fname+" "+lname);
		functionalInterface1.greetUser(" Mahesh","Kumar");

		FunctionalInterface2 functionalInterface23=(a,b)->a+b;
		System.out.println(functionalInterface23.add(100,200));
		
		//FunctionalInterface1 functionalInterface13=str->str.toUpperCase();
		//functionalInterface3.add(100,200);
		
		
	}

}
