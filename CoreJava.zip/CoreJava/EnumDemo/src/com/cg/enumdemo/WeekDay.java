package com.cg.enumdemo;

public enum WeekDay {
	SUN(1,"Sunday");
	private int index;
	private String day;
	
	private WeekDay() {
	}

	private WeekDay(int index, String day) {
		this.index = index;
		this.day = day;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}
	
	
	
}
